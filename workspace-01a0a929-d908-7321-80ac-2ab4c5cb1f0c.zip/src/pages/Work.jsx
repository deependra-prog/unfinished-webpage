import { Link, useSearchParams } from 'react-router-dom'
import { projects } from '../data/projects.js'
import HorizontalScroll from '../components/HorizontalScroll.jsx'
import ProjectCard from '../components/work/ProjectCard.jsx'
import ScrollReveal from '../components/ScrollReveal.jsx'

export default function Work() {
  const [params, setParams] = useSearchParams()
  const cat = params.get('cat')
  const cats = [...new Map(projects.map((p) => [p.cat, p.category])).entries()]
  const shown = cat ? projects.filter((p) => p.cat === cat) : projects

  return (
    <main className="page work-page">
      <section className="page-hero">
        <ScrollReveal as="span" variant="up" className="kicker">ASTERIN WORK</ScrollReveal>
        <ScrollReveal as="h1" variant="clip" className="mega-title">
          WORK THAT <em>MOVES</em>
        </ScrollReveal>
        <ScrollReveal as="p" variant="up" delay={120} className="lead">
          Edits, campaigns, identities and networks. Scroll — the work moves sideways.
        </ScrollReveal>

        <div className="work-filters">
          <button className={!cat ? 'active' : ''} onClick={() => setParams({})}>ALL</button>
          {cats.map(([slug, label]) => (
            <button key={slug} className={cat === slug ? 'active' : ''} onClick={() => setParams({ cat: slug })}>
              {label}
            </button>
          ))}
        </div>
      </section>

      <HorizontalScroll>
        {shown.map((p, i) => (
          <ProjectCard key={p.slug} project={p} index={i} />
        ))}
        <div className="hscroll-end">
          <p>YOUR PROJECT COULD BE NEXT.</p>
          <Link to="/contact" className="btn" data-cursor="GO">START A PROJECT</Link>
        </div>
      </HorizontalScroll>

      <section className="work-cta">
        <ScrollReveal as="h2" variant="clip" className="display-title">
          EVERY FRAME <em>EARNED.</em>
        </ScrollReveal>
        <ScrollReveal as="p" variant="up" className="lead">
          We take on a limited number of creators and networks each quarter.
        </ScrollReveal>
        <ScrollReveal variant="up" delay={100}>
          <Link to="/contact" className="btn btn-ghost" data-cursor="GO">TALK TO US</Link>
        </ScrollReveal>
      </section>
    </main>
  )
}
