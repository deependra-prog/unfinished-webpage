import { Link } from 'react-router-dom'
import ScrollReveal from '../components/ScrollReveal.jsx'
import AmbientBackground from '../components/AmbientBackground.jsx'

const team = [
  { initials: 'AD', role: 'FOUNDER / CREATIVE DIRECTOR', note: 'Sets the visual language. Approves every frame.' },
  { initials: 'VE', role: 'LEAD EDITOR', note: 'Retention-obsessed. Cuts in the dark.' },
  { initials: 'SX', role: 'SERVER ENGINEER', note: 'Keeps TPS at 20 and attackers out.' },
  { initials: 'CM', role: 'SOCIAL STRATEGIST', note: 'Turns feeds into funnels.' }
]

export default function About() {
  return (
    <main className="page about-page">
      <section className="service-hero">
        <div className="service-hero-bg">
          <AmbientBackground density={70} />
          <div className="sh-orb" />
        </div>
        <div className="service-hero-dim" />
        <div className="service-hero-content">
          <ScrollReveal as="span" variant="up" className="kicker">ABOUT ASTERIN</ScrollReveal>
          <ScrollReveal as="h1" variant="clip" className="mega-title">
            BORN IN <em>THE DARK.</em>
          </ScrollReveal>
          <ScrollReveal as="p" variant="up" delay={120} className="lead">
            A creative technology studio built for the internet’s new generation.
          </ScrollReveal>
        </div>
      </section>

      <section className="about-block">
        <ScrollReveal as="span" variant="up" className="kicker">WHO WE ARE</ScrollReveal>
        <ScrollReveal as="h2" variant="clip" className="statement-title">
          ASTERIN IS A STUDIO FOR <em>CREATORS</em>, <em>INFLUENCERS</em> AND THE <em>WORLDS</em> THEY RUN.
        </ScrollReveal>
        <ScrollReveal as="p" variant="up" className="lead about-lead">
          We started where our clients start: editing at 3AM, restarting servers by hand,
          designing thumbnails in borrowed software. ASTERIN is the team we wished we had —
          editors, designers, strategists and engineers under one black-and-red roof.
        </ScrollReveal>
      </section>

      <section className="about-cols">
        <div className="about-col">
          <ScrollReveal as="h3" variant="clip" className="section-title">WHAT WE DO</ScrollReveal>
          <ScrollReveal as="p" variant="up">
            YouTube and Instagram content systems for creators and influencers.
            Minecraft server hosting and management under the PLAYWORLD banner.
            One studio, two worlds, the same standard.
          </ScrollReveal>
        </div>
        <div className="about-col">
          <ScrollReveal as="h3" variant="clip" className="section-title">OUR APPROACH</ScrollReveal>
          <ScrollReveal as="p" variant="up">
            Fewer projects, deeper work. Every engagement becomes a system —
            a visual language, a pipeline, an infrastructure — that keeps compounding
            after we ship. If it doesn’t compound, we don’t sell it.
          </ScrollReveal>
        </div>
        <div className="about-col">
          <ScrollReveal as="h3" variant="clip" className="section-title">OUR WORK</ScrollReveal>
          <ScrollReveal as="p" variant="up">
            Launch campaigns, 90-day growth sprints, documentary edits, identities
            and networks that stay online. See it move in the work section.
          </ScrollReveal>
          <ScrollReveal variant="up" delay={100}>
            <Link to="/work" className="link-arrow" data-cursor="VIEW">VIEW THE WORK →</Link>
          </ScrollReveal>
        </div>
      </section>

      <section className="about-team">
        <div className="section-head">
          <ScrollReveal as="span" variant="up" className="kicker">THE TEAM</ScrollReveal>
          <ScrollReveal as="h2" variant="clip" className="display-title">QUIET <em>PROFESSIONALS</em></ScrollReveal>
        </div>
        <div className="team-grid">
          {team.map((t, i) => (
            <ScrollReveal key={t.role} variant="up" delay={i * 80} className="team-card">
              <span className="team-initials">{t.initials}</span>
              <h4>{t.role}</h4>
              <p>{t.note}</p>
            </ScrollReveal>
          ))}
        </div>
        <ScrollReveal as="p" variant="up" className="team-note">Full profiles drop with the next studio film.</ScrollReveal>
      </section>

      <section className="cta-band">
        <ScrollReveal as="h2" variant="clip" className="display-title">
          WORK WITH <em>ASTERIN.</em>
        </ScrollReveal>
        <ScrollReveal variant="up" delay={100}>
          <Link to="/contact" className="btn btn-large" data-cursor="GO">CONTACT US</Link>
        </ScrollReveal>
      </section>
    </main>
  )
}
