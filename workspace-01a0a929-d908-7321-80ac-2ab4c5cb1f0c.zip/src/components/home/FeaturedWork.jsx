import { Link } from 'react-router-dom'
import { projects } from '../../data/projects.js'
import ScrollReveal from '../ScrollReveal.jsx'

// Full-bleed editorial work grid (reference layout style).
export default function FeaturedWork() {
  return (
    <section className="work-section" id="work">
      <div className="section-head">
        <ScrollReveal as="span" variant="up" className="kicker">SELECTED WORK</ScrollReveal>
        <ScrollReveal as="h2" variant="clip" className="display-title">
          THE WORK <em>SPEAKS</em>
        </ScrollReveal>
        <Link to="/work" className="link-arrow" data-cursor="GO">ALL WORK →</Link>
      </div>

      <div className="work-grid">
        {projects.map((p, i) => (
          <ScrollReveal
            key={p.slug}
            as="div"
            variant="scale"
            delay={(i % 3) * 90}
            className={`work-tile ${i % 5 === 0 ? 'wide' : ''}`}
          >
            <Link to={`/work/${p.slug}`} className="work-tile-link" data-cursor="VIEW">
              <div className="work-tile-media">
                <img src={p.cover} alt={p.title} loading="lazy" />
              </div>
              <div className="work-tile-info">
                <span className="work-tile-cat">{p.category}</span>
                <h3 className="work-tile-title">{p.title}</h3>
                <span className="work-tile-year">{p.year}</span>
              </div>
            </Link>
          </ScrollReveal>
        ))}
      </div>
    </section>
  )
}
