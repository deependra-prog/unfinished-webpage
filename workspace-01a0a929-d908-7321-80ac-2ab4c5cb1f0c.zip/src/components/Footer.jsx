import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-top">
        <p className="footer-cta-line">HAVE A PROJECT, A CHANNEL, OR A WORLD?</p>
        <Link to="/contact" className="footer-cta" data-cursor="GO">
          LET’S BUILD SOMETHING.
        </Link>
      </div>

      <div className="footer-grid">
        <div className="footer-col">
          <span className="footer-head">EXPLORE</span>
          <Link to="/work">Work</Link>
          <Link to="/services">Services</Link>
          <Link to="/products">Products</Link>
          <Link to="/about">About</Link>
        </div>
        <div className="footer-col">
          <span className="footer-head">SUPPORT</span>
          <Link to="/help">Help Center</Link>
          <Link to="/help">Documentation</Link>
          <Link to="/contact">Contact</Link>
        </div>
        <div className="footer-col">
          <span className="footer-head">SOCIALS</span>
          <a href="https://instagram.com" target="_blank" rel="noreferrer">Instagram</a>
          <a href="https://youtube.com" target="_blank" rel="noreferrer">YouTube</a>
          <a href="https://discord.com" target="_blank" rel="noreferrer">Discord</a>
        </div>
        <div className="footer-col">
          <span className="footer-head">CONTACT</span>
          <a href="mailto:hello@asterin.studio">hello@asterin.studio</a>
          <span className="footer-dim">Jodhpur, Rajasthan, IN</span>
        </div>
      </div>

      <div className="footer-word" aria-hidden="true">ASTERIN</div>

      <div className="footer-base">
        <span>© {new Date().getFullYear()} ASTERIN. ALL RIGHTS RESERVED.</span>
        <span>WE BUILD CREATORS &amp; WORLDS</span>
      </div>
    </footer>
  )
}
