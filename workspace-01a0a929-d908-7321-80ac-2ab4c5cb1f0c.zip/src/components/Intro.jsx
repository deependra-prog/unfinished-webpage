import { useEffect, useRef, useState } from 'react'

// ------------------------------------------------------------
// ASTERIN INTRO / STARTUP EXPERIENCE
//
// Drop your own files into:
//   public/assets/video/video.mp4        -> cinematic background video
//   public/assets/logo/logo-animation.mp4 (or .webm) -> logo animation video
// If the files are missing, the built-in animated logo + ambient
// red/black background is used automatically.
// ------------------------------------------------------------

const BG_VIDEO = '/assets/video/video.mp4'
const LOGO_VIDEOS = ['/assets/logo/logo-animation.mp4', '/assets/logo/logo-animation.webm']
const LOGO_IMG = '/assets/logo/logo-transparent.png'

export default function Intro({ onDone }) {
  const [phase, setPhase] = useState('play') // play -> exit -> gone
  const [bgMode, setBgMode] = useState('loading') // loading | video | fallback
  const [logoMode, setLogoMode] = useState('img') // img | video
  const timers = useRef([])
  const finished = useRef(false)

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    // pick logo animation source (mp4 preferred, webm fallback)
    const probe = (src) =>
      fetch(src, { method: 'HEAD' })
        .then((r) => {
          const type = r.headers.get('content-type') || ''
          return r.ok && type.includes('video') ? src : null
        })
        .catch(() => null)
    probe(LOGO_VIDEOS[0])
      .then((hit) => (hit ? hit : probe(LOGO_VIDEOS[1])))
      .then((hit) => setLogoMode(hit ? 'video' : 'img'))

    const finish = () => {
      if (finished.current) return
      finished.current = true
      setPhase('gone')
      onDone()
    }

    if (reduced) {
      timers.current.push(setTimeout(finish, 400))
    } else {
      timers.current.push(setTimeout(() => setPhase('exit'), 4300))
      timers.current.push(setTimeout(finish, 5200))
    }
    return () => timers.current.forEach(clearTimeout)
  }, [onDone])

  const skip = () => {
    setPhase('exit')
    setTimeout(() => {
      if (!finished.current) {
        finished.current = true
        setPhase('gone')
        onDone()
      }
    }, 650)
  }

  if (phase === 'gone') return null

  return (
    <div className={`intro phase-${phase}`} aria-label="ASTERIN intro">
      {/* background: your video, or animated fallback */}
      {bgMode !== 'fallback' && (
        <video
          className="intro-video"
          src={BG_VIDEO}
          autoPlay
          muted
          loop
          playsInline
          onCanPlay={() => setBgMode('video')}
          onError={() => setBgMode('fallback')}
        />
      )}
      {bgMode === 'fallback' && (
        <div className="intro-fallback">
          <div className="fb-orb fb-orb-1" />
          <div className="fb-orb fb-orb-2" />
          <div className="fb-grid" />
        </div>
      )}
      <div className="intro-dim" />

      {/* logo animation */}
      <div className="intro-logo">
        <div className="intro-glow" />
        {logoMode === 'video' ? (
          <video className="intro-logo-video" src={LOGO_VIDEOS[0]} autoPlay muted playsInline />
        ) : (
          <>
            <img className="intro-logo-img" src={LOGO_IMG} alt="ASTERIN" />
          </>
        )}
        <p className="intro-tagline">WE BUILD CREATORS &amp; WORLDS</p>
      </div>

      <div className="intro-bar"><span /></div>
      <button className="intro-skip" onClick={skip}>SKIP</button>
    </div>
  )
}
