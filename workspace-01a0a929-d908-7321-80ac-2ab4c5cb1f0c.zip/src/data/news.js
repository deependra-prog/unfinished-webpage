// ============================================================
// ASTERIN — NEWS / UPDATES DATA
// ============================================================

export const news = [
  {
    date: '10th September 2026',
    title: 'ASTERIN opens its creator program — applications live',
    excerpt: 'We are taking on a new cohort of YouTube and Instagram creators for Q4. Strategy, editing and packaging, run as one system.',
    image: '/assets/images/work/work-youtube.jpg'
  },
  {
    date: '28th August 2026',
    title: 'PLAYWORLD infrastructure upgrade: Ryzen 9 nodes online',
    excerpt: 'Our Mumbai and Frankfurt nodes move to 5.7 GHz Ryzen 9 with NVMe Gen4 RAID — TPS stays pinned at 20.',
    image: '/assets/images/work/work-minecraft.jpg'
  },
  {
    date: '14th August 2026',
    title: 'New editing pipeline cuts delivery time in half',
    excerpt: 'Our review pipeline now ships first cuts 48 hours after footage drop, with versioned feedback built in.',
    image: '/assets/images/work/work-edit.jpg'
  }
]
