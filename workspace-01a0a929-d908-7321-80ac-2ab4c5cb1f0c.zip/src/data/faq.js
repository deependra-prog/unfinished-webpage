// ============================================================
// ASTERIN — FAQ DATA
// ============================================================

export const faq = [
  {
    category: 'GETTING STARTED',
    items: [
      {
        q: 'How do we start a project with ASTERIN?',
        a: 'Send the contact form with your project type. We reply within 48 hours with a short call link. After the call you get a scope, timeline and price — then we start.'
      },
      {
        q: 'Do you work with small creators?',
        a: 'Yes. Some of our best growth stories started with channels under 5k subscribers. We will tell you honestly if you are better off with a template pack instead of a full retainer.'
      },
      {
        q: 'What do you need from me to begin?',
        a: 'Access to your raw footage or channel, your logos if you have them, and 30 minutes on a call. We handle everything else.'
      }
    ]
  },
  {
    category: 'SERVERS',
    items: [
      {
        q: 'How fast is a PLAYWORLD server deployed?',
        a: 'Under 60 seconds after checkout. You get panel access, FTP and console immediately, and your server is live on the nearest node (Mumbai or Frankfurt).'
      },
      {
        q: 'Can you migrate my existing Minecraft server?',
        a: 'Yes. Managed and EMPIRE plans include full migration — worlds, plugins, permissions and IPs — with zero data loss and minimal downtime.'
      },
      {
        q: 'Do you support modpacks and proxies?',
        a: 'All of them: Paper, Spigot, Fabric, Forge, Velocity, BungeeCord and one-click modpack installs from the panel.'
      },
      {
        q: 'What happens if my server gets DDoSed?',
        a: 'Nothing visible. Mitigation is automatic on all plans, up to 1 Tbps on NETHERITE. Players stay connected.'
      }
    ]
  },
  {
    category: 'CONTENT SERVICES',
    items: [
      {
        q: 'How many videos do you edit per month?',
        a: 'Depends on the plan and format. Retainer clients typically ship 4–8 long-form videos and 12–30 shorts per month.'
      },
      {
        q: 'Who owns the final content?',
        a: 'You do. Full ownership of masters, project structure and assets we create for you, forever.'
      },
      {
        q: 'Can you match my existing style?',
        a: 'Yes — or we will propose a stronger one. Every engagement starts with a visual language document you approve before we scale.'
      }
    ]
  },
  {
    category: 'BILLING & SUPPORT',
    items: [
      {
        q: 'How does billing work?',
        a: 'Monthly, in advance, cancel anytime with 14 days notice. Hosting plans are prepaid; studio work is 50% upfront.'
      },
      {
        q: 'Where do I get support?',
        a: 'Hosting: 24/7 via the panel and Discord. Studio work: a dedicated producer on WhatsApp/Discord and email.'
      }
    ]
  }
]
